package heranca;

import java.util.ArrayList;
import java.util.Locale;

public class Principal {
  public static void main(String[]args) {
	  Locale.setDefault(Locale.US);
	  ArrayList<Employee> employees = new ArrayList<>();
	  employees.add(new Employee());
	  employees.add(new OutsourcedEmployee());
	  
	  System.out.println(employees);
  }
}
